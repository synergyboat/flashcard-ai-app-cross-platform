// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'local_database_service.dart';

// **************************************************************************
// FloorGenerator
// **************************************************************************

abstract class $LocalAppDatabaseBuilderContract {
  /// Adds migrations to the builder.
  $LocalAppDatabaseBuilderContract addMigrations(List<Migration> migrations);

  /// Adds a database [Callback] to the builder.
  $LocalAppDatabaseBuilderContract addCallback(Callback callback);

  /// Creates the database and initializes it.
  Future<LocalAppDatabase> build();
}

// ignore: avoid_classes_with_only_static_members
class $FloorLocalAppDatabase {
  /// Creates a database builder for a persistent database.
  /// Once a database is built, you should keep a reference to it and re-use it.
  static $LocalAppDatabaseBuilderContract databaseBuilder(String name) =>
      _$LocalAppDatabaseBuilder(name);

  /// Creates a database builder for an in memory database.
  /// Information stored in an in memory database disappears when the process is killed.
  /// Once a database is built, you should keep a reference to it and re-use it.
  static $LocalAppDatabaseBuilderContract inMemoryDatabaseBuilder() =>
      _$LocalAppDatabaseBuilder(null);
}

class _$LocalAppDatabaseBuilder implements $LocalAppDatabaseBuilderContract {
  _$LocalAppDatabaseBuilder(this.name);

  final String? name;

  final List<Migration> _migrations = [];

  Callback? _callback;

  @override
  $LocalAppDatabaseBuilderContract addMigrations(List<Migration> migrations) {
    _migrations.addAll(migrations);
    return this;
  }

  @override
  $LocalAppDatabaseBuilderContract addCallback(Callback callback) {
    _callback = callback;
    return this;
  }

  @override
  Future<LocalAppDatabase> build() async {
    final path = name != null
        ? await sqfliteDatabaseFactory.getDatabasePath(name!)
        : ':memory:';
    final database = _$LocalAppDatabase();
    database.database = await database.open(
      path,
      _migrations,
      _callback,
    );
    return database;
  }
}

class _$LocalAppDatabase extends LocalAppDatabase {
  _$LocalAppDatabase([StreamController<String>? listener]) {
    changeListener = listener ?? StreamController<String>.broadcast();
  }

  DeckDao? _deckDaoInstance;

  FlashcardDao? _flashcardDaoInstance;

  Future<sqflite.Database> open(
    String path,
    List<Migration> migrations, [
    Callback? callback,
  ]) async {
    final databaseOptions = sqflite.OpenDatabaseOptions(
      version: 1,
      onConfigure: (database) async {
        await database.execute('PRAGMA foreign_keys = ON');
        await callback?.onConfigure?.call(database);
      },
      onOpen: (database) async {
        await callback?.onOpen?.call(database);
      },
      onUpgrade: (database, startVersion, endVersion) async {
        await MigrationAdapter.runMigrations(
            database, startVersion, endVersion, migrations);

        await callback?.onUpgrade?.call(database, startVersion, endVersion);
      },
      onCreate: (database, version) async {
        await database.execute(
            'CREATE TABLE IF NOT EXISTS `deck` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `name` TEXT NOT NULL, `description` TEXT NOT NULL, `createdAt` INTEGER, `updatedAt` INTEGER)');
        await database.execute(
            'CREATE TABLE IF NOT EXISTS `flashcard` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `deckId` INTEGER, `question` TEXT NOT NULL, `answer` TEXT NOT NULL, `createdAt` INTEGER, `updatedAt` INTEGER, `lastReviewed` INTEGER, FOREIGN KEY (`deckId`) REFERENCES `deck` (`id`) ON UPDATE NO ACTION ON DELETE CASCADE)');

        await callback?.onCreate?.call(database, version);
      },
    );
    return sqfliteDatabaseFactory.openDatabase(path, options: databaseOptions);
  }

  @override
  DeckDao get deckDao {
    return _deckDaoInstance ??= _$DeckDao(database, changeListener);
  }

  @override
  FlashcardDao get flashcardDao {
    return _flashcardDaoInstance ??= _$FlashcardDao(database, changeListener);
  }
}

class _$DeckDao extends DeckDao {
  _$DeckDao(
    this.database,
    this.changeListener,
  )   : _queryAdapter = QueryAdapter(database),
        _deckDbEntityInsertionAdapter = InsertionAdapter(
            database,
            'deck',
            (DeckDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'name': item.name,
                  'description': item.description,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt)
                }),
        _flashcardDbEntityInsertionAdapter = InsertionAdapter(
            database,
            'flashcard',
            (FlashcardDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'deckId': item.deckId,
                  'question': item.question,
                  'answer': item.answer,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt),
                  'lastReviewed': _dateTimeConverter.encode(item.lastReviewed)
                }),
        _deckDbEntityUpdateAdapter = UpdateAdapter(
            database,
            'deck',
            ['id'],
            (DeckDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'name': item.name,
                  'description': item.description,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt)
                }),
        _deckDbEntityDeletionAdapter = DeletionAdapter(
            database,
            'deck',
            ['id'],
            (DeckDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'name': item.name,
                  'description': item.description,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt)
                });

  final sqflite.DatabaseExecutor database;

  final StreamController<String> changeListener;

  final QueryAdapter _queryAdapter;

  final InsertionAdapter<DeckDbEntity> _deckDbEntityInsertionAdapter;

  final InsertionAdapter<FlashcardDbEntity> _flashcardDbEntityInsertionAdapter;

  final UpdateAdapter<DeckDbEntity> _deckDbEntityUpdateAdapter;

  final DeletionAdapter<DeckDbEntity> _deckDbEntityDeletionAdapter;

  @override
  Future<DeckDbEntity?> getDeckById(int deckId) async {
    return _queryAdapter.query('SELECT * FROM deck where id = ?1',
        mapper: (Map<String, Object?> row) => DeckDbEntity(
            id: row['id'] as int?,
            name: row['name'] as String,
            description: row['description'] as String,
            createdAt: _dateTimeConverter.decode(row['createdAt'] as int?),
            updatedAt: _dateTimeConverter.decode(row['updatedAt'] as int?)),
        arguments: [deckId]);
  }

  @override
  Future<List<DeckDbEntity>> getAllDecks() async {
    return _queryAdapter.queryList('SELECT * FROM deck',
        mapper: (Map<String, Object?> row) => DeckDbEntity(
            id: row['id'] as int?,
            name: row['name'] as String,
            description: row['description'] as String,
            createdAt: _dateTimeConverter.decode(row['createdAt'] as int?),
            updatedAt: _dateTimeConverter.decode(row['updatedAt'] as int?)));
  }

  @override
  Future<List<FlashcardDbEntity>> getFlashcardsByDeckId(int deckId) async {
    return _queryAdapter.queryList('SELECT * FROM flashcard WHERE deckId = ?1',
        mapper: (Map<String, Object?> row) => FlashcardDbEntity(
            id: row['id'] as int?,
            deckId: row['deckId'] as int?,
            question: row['question'] as String,
            answer: row['answer'] as String,
            createdAt: _dateTimeConverter.decode(row['createdAt'] as int?),
            updatedAt: _dateTimeConverter.decode(row['updatedAt'] as int?),
            lastReviewed:
                _dateTimeConverter.decode(row['lastReviewed'] as int?)),
        arguments: [deckId]);
  }

  @override
  Future<void> deleteDeck(int deckId) async {
    await _queryAdapter
        .queryNoReturn('DELETE FROM deck WHERE id = ?1', arguments: [deckId]);
  }

  @override
  Future<int> createDeck(DeckDbEntity deck) {
    return _deckDbEntityInsertionAdapter.insertAndReturnId(
        deck, OnConflictStrategy.abort);
  }

  @override
  Future<void> addMultipleFlashcardsToDeck(
      List<FlashcardDbEntity> flashcards) async {
    await _flashcardDbEntityInsertionAdapter.insertList(
        flashcards, OnConflictStrategy.abort);
  }

  @override
  Future<void> updateDeck(DeckDbEntity deck) async {
    await _deckDbEntityUpdateAdapter.update(deck, OnConflictStrategy.abort);
  }

  @override
  Future<void> deleteDeckEntity(DeckDbEntity deck) async {
    await _deckDbEntityDeletionAdapter.delete(deck);
  }

  @override
  Future<int> createDeckWithFlashcards(
    DeckDbEntity deck,
    List<FlashcardDbEntity> flashcards,
  ) async {
    if (database is sqflite.Transaction) {
      return super.createDeckWithFlashcards(deck, flashcards);
    } else {
      return (database as sqflite.Database)
          .transaction<int>((transaction) async {
        final transactionDatabase = _$LocalAppDatabase(changeListener)
          ..database = transaction;
        return transactionDatabase.deckDao
            .createDeckWithFlashcards(deck, flashcards);
      });
    }
  }
}

class _$FlashcardDao extends FlashcardDao {
  _$FlashcardDao(
    this.database,
    this.changeListener,
  )   : _queryAdapter = QueryAdapter(database),
        _flashcardDbEntityInsertionAdapter = InsertionAdapter(
            database,
            'flashcard',
            (FlashcardDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'deckId': item.deckId,
                  'question': item.question,
                  'answer': item.answer,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt),
                  'lastReviewed': _dateTimeConverter.encode(item.lastReviewed)
                }),
        _flashcardDbEntityUpdateAdapter = UpdateAdapter(
            database,
            'flashcard',
            ['id'],
            (FlashcardDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'deckId': item.deckId,
                  'question': item.question,
                  'answer': item.answer,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt),
                  'lastReviewed': _dateTimeConverter.encode(item.lastReviewed)
                }),
        _flashcardDbEntityDeletionAdapter = DeletionAdapter(
            database,
            'flashcard',
            ['id'],
            (FlashcardDbEntity item) => <String, Object?>{
                  'id': item.id,
                  'deckId': item.deckId,
                  'question': item.question,
                  'answer': item.answer,
                  'createdAt': _dateTimeConverter.encode(item.createdAt),
                  'updatedAt': _dateTimeConverter.encode(item.updatedAt),
                  'lastReviewed': _dateTimeConverter.encode(item.lastReviewed)
                });

  final sqflite.DatabaseExecutor database;

  final StreamController<String> changeListener;

  final QueryAdapter _queryAdapter;

  final InsertionAdapter<FlashcardDbEntity> _flashcardDbEntityInsertionAdapter;

  final UpdateAdapter<FlashcardDbEntity> _flashcardDbEntityUpdateAdapter;

  final DeletionAdapter<FlashcardDbEntity> _flashcardDbEntityDeletionAdapter;

  @override
  Future<List<FlashcardDbEntity>> getAllFlashcardsFromDeckId(int deckId) async {
    return _queryAdapter.queryList('SELECT * FROM flashcard WHERE deckId = ?1',
        mapper: (Map<String, Object?> row) => FlashcardDbEntity(
            id: row['id'] as int?,
            deckId: row['deckId'] as int?,
            question: row['question'] as String,
            answer: row['answer'] as String,
            createdAt: _dateTimeConverter.decode(row['createdAt'] as int?),
            updatedAt: _dateTimeConverter.decode(row['updatedAt'] as int?),
            lastReviewed:
                _dateTimeConverter.decode(row['lastReviewed'] as int?)),
        arguments: [deckId]);
  }

  @override
  Future<void> deleteFlashcardById(int flashcardId) async {
    await _queryAdapter.queryNoReturn('DELETE FROM flashcard WHERE id = ?1',
        arguments: [flashcardId]);
  }

  @override
  Future<void> createFlashcard(FlashcardDbEntity flashcard) async {
    await _flashcardDbEntityInsertionAdapter.insert(
        flashcard, OnConflictStrategy.abort);
  }

  @override
  Future<void> updateFlashcard(FlashcardDbEntity flashcard) async {
    await _flashcardDbEntityUpdateAdapter.update(
        flashcard, OnConflictStrategy.abort);
  }

  @override
  Future<void> deleteFlashcard(FlashcardDbEntity flashcard) async {
    await _flashcardDbEntityDeletionAdapter.delete(flashcard);
  }
}

// ignore_for_file: unused_element
final _dateTimeConverter = DateTimeConverter();
